        require('./revealer.js');
        require('./lazyLoad');
        require('./list-section-menu.js');
        require('./smoothScroll.js');
        require('bootstrap');
        require('./simpleUploader.js');
        require('./simpleAlerts.js');
        require('./parallax.js');
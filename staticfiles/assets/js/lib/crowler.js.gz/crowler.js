var ts = new Date();
var s = 'https://app-vlc.hotmart.com/market/search?q=web';
var _hse = {
    coo:	false,
    dl:	 s, //search
    ec:	 7,
    ev:	 'PageView', //evt
    fbp: 'fb.1.1544785278524.1746422866', //fb
    id:	170632606897581, 
    if:	false,
    it:	1544787068138,
    o:	30,
    r:	'stable', //release
    rl:	"",
    sh:	768,
    sw:	1360,
    ts:	1544788345978, //time server
    v:	'2.8.35',
}
var _data = data;
_data.id = 1703776723211142;
_data.ts = ts;

  JSON.parse(decodeURIComponent("%7B%22meteorRelease%22%3A%22METEOR%401.8.0.1%22%2C%22meteorEnv%22%3A%7B%22NODE_ENV%22%3A%22production%22%2C%22TEST_METADATA%22%3A%22%7B%7D%22%7D%2C%22PUBLIC_SETTINGS%22%3A%7B%22facebook%22%3A%7B%22appId%22%3A%22863367583748830%22%7D%2C%22hotmart%22%3A%7B%22ads%22%3A%22https%3A%2F%2Fapp-ads.hotmart.com%22%2C%22analytics%22%3A%22https%3A%2F%2Fanalytics.hotmart.com%2Fhome%22%2C%22checkout%22%3A%22https%3A%2F%2Fpay.hotmart.com%22%2C%22checkoutCustom%22%3A%22https%3A%2F%2Fcustom-checkout.hotmart.com%22%2C%22drive%22%3A%22https%3A%2F%2Fclubdrive-api.hotmart.com%2Fclub-drive-api%2Frest%2Fv1%2Faccess%22%2C%22hotConnect%22%3A%22https%3A%2F%2Fapp-connect.hotmart.com%22%2C%22listboss%22%3A%22https%3A%2F%2Fapp-listboss.hotmart.com%22%2C%22player%22%3A%22https%3A%2F%2Fplaybox.hotmart.com%22%2C%22thumbor%22%3A%22https%3A%2F%2Fapi-thumbor.hotmart.com%22%2C%22v1%22%3A%22https%3A%2F%2Fapp.hotmart.com%2Fvulcano%22%2C%22vulcano%22%3A%22https%3A%2F%2Fapp-vlc.hotmart.com%22%2C%22webhook%22%3A%22https%3A%2F%2Fapp-postback.hotmart.com%22%2C%22profile%22%3A%22https%3A%2F%2Fprofile.hotmart.com%22%7D%2C%22firebase%22%3A%7B%22apiKey%22%3A%22AIzaSyBOLC1TuiC68Fy8Mpc4x7X6hbKt6Uej0vc%22%2C%22authDomain%22%3A%22vulcanoalerts-207916.firebaseapp.com%22%2C%22databaseURL%22%3A%22https%3A%2F%2Fvulcanoalerts.firebaseio.com%22%2C%22projectId%22%3A%22vulcanoalerts-207916%22%2C%22storageBucket%22%3A%22vulcanoalerts-207916.appspot.com%22%2C%22messagingSenderId%22%3A%22105306823732%22%7D%2C%22mode%22%3A%22prod%22%2C%22tosVersion%22%3A1.2%7D%2C%22ROOT_URL%22%3A%22https%3A%2F%2Fapp-vlc.hotmart.com%2F%22%2C%22ROOT_URL_PATH_PREFIX%22%3A%22%22%2C%22autoupdate%22%3A%7B%22versions%22%3A%7B%22web.browser%22%3A%7B%22version%22%3A%2228b142a41d4f8635203c5661cdc1a0952513e44e%22%2C%22versionRefreshable%22%3A%2248bfdd03f1647a4da80bdcd560292c8b0d03b69b%22%2C%22versionNonRefreshable%22%3A%225ba1ee69755b3207aa5ba1ca876c6904eaf41fc8%22%7D%2C%22web.browser.legacy%22%3A%7B%22version%22%3A%223a7d7917b21fee1637e63f087d85f4b5cd07d833%22%2C%22versionRefreshable%22%3A%2248bfdd03f1647a4da80bdcd560292c8b0d03b69b%22%2C%22versionNonRefreshable%22%3A%229e7d2b160886f42bd1b2ae5e47239b12b9c75675%22%7D%7D%2C%22autoupdateVersion%22%3Anull%2C%22autoupdateVersionRefreshable%22%3Anull%2C%22autoupdateVersionCordova%22%3Anull%2C%22appId%22%3A%22epgc241vtro5x1wjo6nl%22%7D%2C%22appId%22%3A%22epgc241vtro5x1wjo6nl%22%2C%22isModern%22%3Atrue%7D"))
  $.get('https://api-hot-connect.hotmart.com/affiliation/rest/v2/', function(r){console.log(r)})
  $.get('https://api-hot-connect.hotmart.com/product/rest/v2/eyJzaWQiOiI0MDNhZmYzOWZmYjk0NTZhODcyZDcxNGUzMTRjYTMyYSIsInBhZ2V2aWV3X2lkIjoiUFZ0anNqMTF0cmpjanBvODNtd2MiLCJ0cmFjZV9pZCI6IkxUMXdmaGR4NTd0dzZqcG84M213YyJ9', function(r){console.log(r)})
  $.get('https://api-hot-connect.hotmart.com/product/rest/v2/50', function(r){console.log(r)})